import os
import tkinter as tk
from tkinter import ttk

def tampilkan_gui_leaderboard():
    # Membuat Jendela Utama GUI
    root = tk.Tk()
    root.title("Leaderboard Wordle")
    root.geometry("650x450")
    root.configure(bg="#00afc6")

    # Judul
    lbl_title = tk.Label(
        root, 
        text="WORDLE LEADERBOARD", 
        font = ("DM Sans", 16, "bold"), 
        bg = "#0400E9", 
        fg = "#ffffff"
    )
    lbl_title.pack(pady = 15)


    frame_tabel = tk.Frame(root)
    frame_tabel.pack(padx = 20, pady = 10, fill = tk.BOTH, expand = True)


    scrollbar = ttk.Scrollbar(frame_tabel)
    scrollbar.pack(side = tk.RIGHT, fill = tk.Y)

    # Buat Tabel (pake Treeview)
    kolom = ("Peringkat", "Username", "Total Tebakan", "Jumlah Game")
    tabel = ttk.Treeview (
        frame_tabel, 
        columns = kolom, 
        show = "headings", 
        yscrollcommand = scrollbar.set, 
        height = 8
    )
    scrollbar.config(command = tabel.yview)

    # Mengatur Header dan Lebar Kolom
    tabel.heading("Peringkat", text = "No")
    tabel.heading("Username", text = "Username")
    tabel.heading("Total Tebakan", text = "Total Skor")
    tabel.heading("Jumlah Game", text = "Main (Game)")

    tabel.column("Peringkat", width = 50, anchor= "center")
    tabel.column("Username", width = 140, anchor= "w")
    tabel.column("Total Tebakan", width = 50, anchor = "center")
    tabel.column("Jumlah Game", width = 50, anchor = "center")

    tabel.pack(fill=tk.BOTH, expand=True)

    # Masukkin data dari leaderboard.txt ke tabel
    file_path = "leaderboard.txt"
    if os.path.exists(file_path):
        data_leaderboard = []
        with open(file_path, "r") as file:
            for line in file:
                line = line.strip()
                if line:
                    parts = line.split(",")
                    if len(parts) >= 3:
                        username = parts[0]
                        total_skor = int(parts[1])
                        total_game = int(parts[2])
                        data_leaderboard.append((username, total_skor, total_game))

        # Urutin berdasarkan total tebakan tersedikit / paling efisien
        data_leaderboard.sort(key = lambda x: x[1])

        # Memasukkan data ke dalam GUI Treeview
        for rank, (username, total_skor, total_game) in enumerate(data_leaderboard, start = 1):
            tabel.insert("", tk.END, values = (f"#{rank}", username, total_skor, total_game))

    # Tombol Tutup
    btn_close = tk.Button (
        root, 
        text="Tutup", 
        font=("DM Sans", 14, "bold"), 
        bg="#e74c3c", 
        fg="white", 
        command=root.destroy
    )
    btn_close.pack(pady=10)

    # Jalankan Loop GUI
    root.mainloop()

# Jalankan fungsi jika file dipanggil langsung
if __name__ == "__main__":
    tampilkan_gui_leaderboard()