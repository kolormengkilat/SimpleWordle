from leaderboard_gui import tampilkan_gui_leaderboard
import random
from collections import Counter

# Hint system (wordle solver otomatis di background)
def get_best_guess(possible_words):
    if not possible_words:
        return None
    letter_counts = Counter()
    for word in possible_words:
        letter_counts.update(set(word))
        
    def score_word(word):
        return sum(letter_counts[char] for char in set(word))
        
    best_words = sorted(possible_words, key=score_word, reverse=True)
    return best_words[0]

def filter_words(possible_words, guess, feedback):
    new_possible = []
    for word in possible_words:
        is_valid = True
        temp_word = list(word)
        for i in range(5):
            if feedback[i] == 'G':
                if word[i] != guess[i]:
                    is_valid = False
                    break
                temp_word[i] = None
        if not is_valid: continue
        for i in range(5):
            if feedback[i] == 'Y':
                if guess[i] not in temp_word or word[i] == guess[i]:
                    is_valid = False
                    break
                temp_word[temp_word.index(guess[i])] = None 
            elif feedback[i] == 'X':
                if word[i] == guess[i] or guess[i] in temp_word:
                    is_valid = False
                    break
        if is_valid:
            new_possible.append(word)
    return new_possible

# Wordle
guess = 0
words = []

with open("words.txt", "r") as file:
    for line in file:
        if len(line.strip()) == 5:
            words.append(line.strip())

existing_usernames = []
try:
    with open("leaderboard.txt", "r") as file:
        existing_usernames = [line.split(",")[0].strip() for line in file if line.strip()]
except FileNotFoundError:
    pass

option = str(input("Mode permainan: single, 5 (quintuple), atau inf (infinite)? (Ketik 1, 5, atau inf): "))
session = 0

if option == "1":
    session_limit = 1
elif option == "5":
    session_limit = 5
elif option == "inf":
    session_limit = None
else:
    session_limit = 1

score = 0
index = random.randint(0, len(words) - 1)
word_to_guess = words[index]

possible_words = list(words) 

# print(word_to_guess) [hapus pagar for debugging purposes]
print("\nGame Dimulai! (Ketik 'hint' jika butuh bantuan)")

while True:
    word_guess = input("Guess the word (type 'x' to give up, 'hint' for help): ").strip().lower()

    # FITUR HINT
    if word_guess == "hint":
        best = get_best_guess(possible_words)
        if best:
            print(f"[SYSTEM HINT]: Coba tebak kata '{best.upper()}' (Tersisa {len(possible_words)} kemungkinan)")
        else:
            print("[SYSTEM HINT]: Tidak ada kata yang tersisa/cocok di kamus.")
        continue # Lanjut ke loop tanpa menambah jumlah tebakan

    # FITUR MENYERAH
    if word_guess == "x":
        print("The correct word is " + word_to_guess.upper())
        break
        
    # VALIDASI KATA
    if word_guess not in words:
        print("Word is not in the list")
        continue

    # EVALUATION LOGIC
    marks = ["⬛"] * 5
    feedback_list = ["X"] * 5
    temp_target = list(word_to_guess)

    for i in range(5):
        if word_guess[i] == word_to_guess[i]:
            marks[i] = "🟩"
            feedback_list[i] = "G"
            temp_target[i] = None

    for i in range(5):
        if feedback_list[i] == "X" and word_guess[i] in temp_target:
            marks[i] = "🟨"
            feedback_list[i] = "Y"
            temp_target[temp_target.index(word_guess[i])] = None

    print("".join(marks))
    
    feedback_str = "".join(feedback_list)
    possible_words = filter_words(possible_words, word_guess, feedback_str)
    
    guess += 1

    # WIN CONDITION
    if word_guess == word_to_guess:
        print("You win!")
        session += 1
        score += guess
        guess = 0

        if session_limit is not None and session == session_limit:
            print(f"You completed {session_limit} rounds with a score of {score}")
            option_save = str(input("Save? (Y/N): ")).upper()
            if option_save == "Y":
                while True:
                    username = input("Insert username: ").strip()
                    if username in existing_usernames:
                        print("Username already taken")
                    else:
                        break
                with open("leaderboard.txt", "a") as file:
                    file.write(f"{username},{score},{session}\n")
                tampilkan_gui_leaderboard()
            break
            
        elif option == "inf":
            option_continue = str(input("Continue? (Y/N): ")).upper()
            if option_continue == "Y":
                index = random.randint(0, len(words) - 1)
                word_to_guess = words[index]
                possible_words = list(words)
                print("\nRonde Baru Dimulai!")
                continue
            else:
                print(f"You completed {session} games with a score of {score}")
                option_save = str(input("Save? (Y/N): ")).upper()
                if option_save == "Y":
                    while True:
                        username = input("Insert username: ").strip()
                        if username in existing_usernames:
                            print("Username already taken")
                        else:
                            break
                    with open("leaderboard.txt", "a") as file:
                        file.write(f"{username},{score},{session}\n")
                    tampilkan_gui_leaderboard()
                break
                
        else:
            # Quintuple Mode
            index = random.randint(0, len(words) - 1)
            word_to_guess = words[index]
            possible_words = list(words)
            print(f"\nRonde {session + 1} Dimulai!")

    # LOSE CONDITION
    elif guess >= 6:
        print("You lose! The correct word is " + word_to_guess.upper())
        break